# Generated code do not commit.
file(TO_CMAKE_PATH "/workspaces/Fidel-Crossword-Ethiopia/flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "/workspaces/Fidel-Crossword-Ethiopia/app" PROJECT_DIR)

set(FLUTTER_VERSION "1.0.0+1" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 1 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=/workspaces/Fidel-Crossword-Ethiopia/flutter"
  "PROJECT_DIR=/workspaces/Fidel-Crossword-Ethiopia/app"
  "DART_DEFINES=RkxVVFRFUl9CVUlMRF9OQU1FPTEuMC4w,RkxVVFRFUl9CVUlMRF9OVU1CRVI9MQ==,RkxVVFRFUl9WRVJTSU9OPTMuNDcuMC0xLjAucHJlLTEyNQ==,RkxVVFRFUl9DSEFOTkVMPW1hc3Rlcg==,RkxVVFRFUl9HSVRfVVJMPWh0dHBzOi8vZ2l0aHViLmNvbS9mbHV0dGVyL2ZsdXR0ZXIuZ2l0,RkxVVFRFUl9GUkFNRVdPUktfUkVWSVNJT049ODAwNTc5M2MzNQ==,RkxVVFRFUl9FTkdJTkVfUkVWSVNJT049ODAwNTc5M2MzNQ==,RkxVVFRFUl9EQVJUX1ZFUlNJT049My4xNC4wIChidWlsZCAzLjE0LjAtNDEuMC5kZXYp"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=/workspaces/Fidel-Crossword-Ethiopia/app/.dart_tool/package_config.json"
  "FLUTTER_TARGET=/workspaces/Fidel-Crossword-Ethiopia/app/lib/main.dart"
)
